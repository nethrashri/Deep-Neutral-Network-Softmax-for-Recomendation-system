# Deep-Neutral-Network-Softmax-for-Recomendation-system
We will create a movie recommendation system based on the MovieLens dataset available here. The data consists of movies ratings
